//import {action } from 'mobx';
class Actions {
    constructor(store) {
        this.store = store;
    }
    /*
    @action
    incA = () => {
        this.store.xxxxx++;
    }*/
}
export default Actions;
