import { observable, action } from 'mobx';
// 定义数据结构
class Store {
}
export default Store;
