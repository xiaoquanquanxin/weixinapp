// import {action } from 'mobx';
// 定义对数据的操作
class Actions {
    constructor(store) {
        this.store = store;
    }
    // incA = () => {
    //      this._test()
    // }


}
export default Actions;
